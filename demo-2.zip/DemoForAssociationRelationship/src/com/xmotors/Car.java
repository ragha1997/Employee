package com.xmotors;

import com.xsystem.MusicSystem;

public class Car {
	
	private Engine engineRef = new Engine();
	
	private MusicSystem ms;
	
	public Car(MusicSystem ms){
		this.ms = ms;
	}

	public Engine getEngine(){
		return engineRef;
	}
	
	public MusicSystem getMusicSystem() {
		return ms;
	}
	
	public void setMusicSystem(MusicSystem ms) {
		this.ms = ms;
	}
	
	
}



