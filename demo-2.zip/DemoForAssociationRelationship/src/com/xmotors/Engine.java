package com.xmotors;

public class Engine {

	private int capacity = 1200;
	
	public int getCapacity(){
		return capacity;
	}
	
	
}
