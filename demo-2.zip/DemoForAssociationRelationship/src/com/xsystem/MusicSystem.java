package com.xsystem;

public class MusicSystem {
	private String name = "Pioneer";
	
	public String getName() {
		return name;
	}
	
	public MusicSystem(String name) {
		this.name = name;
	}
	
	
}
