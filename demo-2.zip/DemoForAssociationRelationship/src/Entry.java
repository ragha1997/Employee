import com.xmotors.Car;
import com.xmotors.Engine;
import com.xsystem.MusicSystem;

public class Entry {

	public static void main(String[] args) {
		MusicSystem ms = new MusicSystem("Pioneer");
		Car carRef = new Car(ms);
		
		int capacity = carRef.getEngine().getCapacity();
		System.out.println(capacity);
		
		System.out.println(carRef.getMusicSystem().getName());
		

		ms = new MusicSystem("Pioneer");
		
		carRef.setMusicSystem(ms);
		System.out.println(carRef.getMusicSystem().getName());

		MusicSystem ms2 = new MusicSystem("Sony");
		Car car2 = new Car(ms2);
		
//		car2.engineRef = new Engine();
		
		System.out.println(car2.getMusicSystem().getName());
		System.out.println(carRef.getMusicSystem().getName());
		
	}
	
	
}
